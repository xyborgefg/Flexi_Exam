﻿using Microsoft.AspNetCore.Hosting;
using opg_201910_interview.Contracts;
using opg_201910_interview.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace opg_201910_interview.Repository
{
    public class UploadFilesRepository : IUploadFilesRepository
    {
        private readonly IWebHostEnvironment _hostEnvironment;

        public UploadFilesRepository(IWebHostEnvironment hostingEnvironment)
        {
            _hostEnvironment = hostingEnvironment;
        }

        public IEnumerable<UploadFiles> GetUploadFiles(string ControllerName, string ActionName, string DateFormat)
        {
            List<UploadFiles> _uploadFiles = new List<UploadFiles>();
            string _fileName = string.Empty;
            string index = DateFormat == "yyyy-MM-dd" ? "-" : "_";

            foreach (string file in Directory.GetFiles(Path.Combine(_hostEnvironment.ContentRootPath, ControllerName, ActionName), "*.xml"))
            {
                _fileName = Path.GetFileNameWithoutExtension(file);
                try
                {
                    if (_fileName.Contains(Convert.ToDateTime(_fileName.Remove(0, _fileName.IndexOf(Convert.ToChar(index)) + 1)).ToString(DateFormat)))
                        _uploadFiles.Add(new UploadFiles() { Name = _fileName, DateCreated = File.GetCreationTime(file) });
                }
                catch { }
            }

            return _uploadFiles;
        }
    }
}
