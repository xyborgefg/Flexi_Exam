﻿using opg_201910_interview.Models;
using System.Collections.Generic;

namespace opg_201910_interview.Contracts
{
    public interface IUploadFilesRepository
    {
        IEnumerable<UploadFiles> GetUploadFiles(string ControllerName, string ActionName, string DateFormat);
    }
}
