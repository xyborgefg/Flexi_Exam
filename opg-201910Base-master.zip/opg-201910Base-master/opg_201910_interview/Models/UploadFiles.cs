﻿using System;

namespace opg_201910_interview.Models
{
    public class UploadFiles
    {
        public string Name { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
