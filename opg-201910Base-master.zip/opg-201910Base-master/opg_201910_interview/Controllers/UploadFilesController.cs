﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using opg_201910_interview.Contracts;
using opg_201910_interview.Models;

namespace opg_201910_interview.Controllers
{
    public class UploadFilesController : Controller
    {
        private IUploadFilesRepository _uploadFilesRepository;

        public UploadFilesController(IUploadFilesRepository uploadFilesRepository)
        {
            _uploadFilesRepository = uploadFilesRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ClientA()
        {
            IEnumerable<UploadFiles> model = _uploadFilesRepository.GetUploadFiles(
                this.ControllerContext.ActionDescriptor.ControllerName,
                this.ControllerContext.ActionDescriptor.ActionName, "yyyy-MM-dd");

            return View(model);
        }

        public IActionResult ClientB()
        {
            IEnumerable<UploadFiles> model = _uploadFilesRepository.GetUploadFiles(
                this.ControllerContext.ActionDescriptor.ControllerName,
                this.ControllerContext.ActionDescriptor.ActionName, "yyyyMMdd");

            return View(model);
        }
    }
}
